Email Tracker
Version:  1.0
Date:     10-05-2016
Author:   Tayyib Oladoja
Website:  www.tayyiboladoja.com

Features:
1. Track email
2. Displays recipient’s city and country
3. Device details
4. Number of times opened.


How to use.
1. Extract files to web server
2. Setup  config.php
3. Tables will be automatically created
4. Open index.php file to generate tracking code
5. Attach tracking code to you email.
6. Refresh index for report.
